import logging
from .data_connector import DataConnector
from .trainer import Trainer
from .generator import Generator
from typing import Union, Optional
import pandas as pd

class Gener8Engine:
    """Main engine for synthetic data generation."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.data_connector = DataConnector()
        self.trainer = Trainer()
        self.generator = Generator(self.trainer)
        self.logger.info("Gener8 engine initialized")
    
    def load_and_train(self, source: Union[str, pd.DataFrame], 
                       file_type: Optional[str] = None, 
                       n_components: int = 3) -> None:
        """
        Load data and train the model.
        
        Args:
            source: Path to file or DataFrame
            file_type: Type of file (csv, json, excel)
            n_components: Number of mixture components
        """
        data = self.data_connector.load_data(source, file_type)
        self.trainer.train(data, n_components)
    
    def generate(self, n_samples: int) -> pd.DataFrame:
        """
        Generate synthetic data.
        
        Args:
            n_samples: Number of samples to generate
            
        Returns:
            DataFrame containing synthetic data
        """
        return self.generator.generate(n_samples)

if __name__ == "__main__":
    # Example usage
    logging.basicConfig(level=logging.INFO)
    import numpy as np
    
    # Initialize engine
    engine = Gener8Engine()
    
    # Create sample data
    sample_data = pd.DataFrame({
        'age': np.random.normal(30, 10, 1000),
        'income': np.random.normal(50000, 10000, 1000),
        'category': np.random.choice(['A', 'B', 'C'], 1000)
    })
    
    # Load and train
    engine.load_and_train(sample_data)
    
    # Generate synthetic data
    synthetic_data = engine.generate(100)
    print(synthetic_data.head())