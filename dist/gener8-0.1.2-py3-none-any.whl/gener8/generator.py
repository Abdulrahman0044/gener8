import pandas as pd
import numpy as np
import logging
from typing import Tuple

class Generator:
    """Generates synthetic data based on trained model, preserving input data structure."""
    
    def __init__(self, trainer: 'Trainer'):
        self.logger = logging.getLogger(__name__)
        self.trainer = trainer
    
    def generate(self, n_samples: int) -> pd.DataFrame:
        """
        Generate synthetic data with the same structure as the input, including missing values.
        
        Args:
            n_samples: Number of samples to generate
            
        Returns:
            DataFrame containing synthetic data
        """
        if self.trainer.model is None:
            raise ValueError("Model not trained. Run Trainer.train() first.")
                
        try:
            # Generate samples for numeric columns
            samples, _ = self.trainer.model.sample(n_samples)
            
            # Inverse transform to original scale
            samples = self.trainer.scaler.inverse_transform(samples)
            
            # Create DataFrame for numeric data
            synthetic_data = pd.DataFrame(samples, columns=self.trainer.columns)
            
            # Add missing values to numeric columns based on original proportions
            for col in self.trainer.columns:
                missing_prop = self.trainer.missing_proportions.get(col, 0.0)
                if missing_prop > 0:
                    mask = np.random.random(n_samples) < missing_prop
                    synthetic_data.loc[mask, col] = np.nan
            
            # Add categorical columns with random sampling from original data
            if self.trainer.data is not None and len(self.trainer.categorical_columns) > 0:
                for col in self.trainer.categorical_columns:
                    valid_values = self.trainer.data[col].dropna().values
                    if len(valid_values) == 0:
                        self.logger.warning(f"No valid values for column {col}; filling with NaN")
                        synthetic_data[col] = np.nan
                    else:
                        synthetic_data[col] = np.random.choice(valid_values, size=n_samples)
                        # Add missing values based on original proportions
                        missing_prop = self.trainer.missing_proportions.get(col, 0.0)
                        if missing_prop > 0:
                            mask = np.random.random(n_samples) < missing_prop
                            synthetic_data.loc[mask, col] = np.nan
            
            # Ensure all original columns are present in the output
            all_columns = list(self.trainer.data.columns) if self.trainer.data is not None else list(self.trainer.columns)
            synthetic_data = synthetic_data.reindex(columns=all_columns)
            
            # Restore original dtypes
            for col, dtype in self.trainer.dtypes.items():
                if col in synthetic_data.columns:
                    try:
                        synthetic_data[col] = synthetic_data[col].astype(dtype)
                    except (ValueError, TypeError) as e:
                        self.logger.warning(f"Could not convert column {col} to {dtype}: {str(e)}")
            
            return synthetic_data
                
        except Exception as e:
            self.logger.error(f"Error generating data: {str(e)}")
            raise