import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.mixture import GaussianMixture
import logging

class Trainer:
    """Trains a model on the input data, handling missing values by training on complete cases."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.scaler = StandardScaler()
        self.model = None
        self.columns = None
        self.categorical_columns = None
        self.data = None
        self.missing_proportions = None
        self.dtypes = None
    
    def preprocess_data(self, data: pd.DataFrame) -> np.ndarray:
        """
        Preprocess data for training by dropping rows with NaN in numeric columns and scaling.
        
        Args:
            data: Input DataFrame
            
        Returns:
            Scaled numerical data
        """
        # Identify numeric and categorical columns
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        categorical_cols = data.select_dtypes(exclude=[np.number]).columns
        
        if len(numeric_cols) == 0:
            raise ValueError("No numeric columns found in data")
            
        self.columns = numeric_cols
        self.categorical_columns = categorical_cols
        self.dtypes = data.dtypes.to_dict()
        
        # Calculate missing proportions for each column
        self.missing_proportions = data.isna().mean().to_dict()
        
        # Drop rows with NaN in numeric columns for training
        clean_data = data[numeric_cols].dropna()
        if len(clean_data) == 0:
            raise ValueError("No complete cases (rows without NaN) in numeric columns")
            
        # Scale numeric data
        scaled_data = self.scaler.fit_transform(clean_data)
        
        return scaled_data
    
    def train(self, data: pd.DataFrame, n_components: int = 3) -> None:
        """
        Train Gaussian Mixture Model on complete cases.
        
        Args:
            data: Input DataFrame
            n_components: Number of training components
        """
        try:
            self.data = data
            processed_data = self.preprocess_data(data)
            if processed_data.shape[0] < n_components:
                raise ValueError(
                    f"Number of complete cases ({processed_data.shape[0]}) is less than "
                    f"n_components ({n_components})"
                )
            self.model = GaussianMixture(n_components=n_components, 
                                       random_state=42)
            self.model.fit(processed_data)
            self.logger.info(f"Model trained successfully with {n_components} components")
            
        except Exception as e:
            self.logger.error(f"Error training model: {str(e)}")
            raise