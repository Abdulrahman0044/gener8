import pandas as pd
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.preprocessing import StandardScaler, LabelEncoder
from typing import Dict, Optional
import logging
import time
import copy

class GeneratorNN(nn.Module):
    """Neural network for generating synthetic data."""
    def __init__(self, input_dim, output_dim, hidden_dim=128):
        super(GeneratorNN, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.ReLU(),
            nn.Linear(hidden_dim * 2, output_dim)
        )
    
    def forward(self, x):
        return self.model(x)

class DiscriminatorNN(nn.Module):
    """Neural network for discriminating real vs. synthetic data."""
    def __init__(self, input_dim, hidden_dim=128):
        super(DiscriminatorNN, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, hidden_dim * 2),
            nn.ReLU(),
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        return self.model(x)

class Trainer:
    """Trains a GAN-based model on the input data, handling missing values."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.model_generator = None
        self.model_discriminator = None
        self.columns = None
        self.categorical_columns = None
        self.data = None
        self.missing_proportions = None
        self.dtypes = None
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    def preprocess_data(self, data: pd.DataFrame) -> np.ndarray:
        """
        Preprocess data for training by dropping rows with NaN in numeric columns and encoding.
        
        Args:
            data: Input DataFrame
            
        Returns:
            Preprocessed numerical and encoded categorical data
        """
        # Identify numeric and categorical columns
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        categorical_cols = data.select_dtypes(exclude=[np.number]).columns
        
        if len(numeric_cols) == 0:
            raise ValueError("No numeric columns found in data")
            
        self.columns = numeric_cols
        self.categorical_columns = categorical_cols
        self.dtypes = data.dtypes.to_dict()
        self.missing_proportions = data.isna().mean().to_dict()
        
        # Drop rows with NaN in numeric columns for training
        clean_data = data[numeric_cols].dropna()
        if len(clean_data) == 0:
            raise ValueError("No complete cases in numeric columns")
        
        # Scale numeric data
        numeric_scaled = self.scaler.fit_transform(clean_data)
        
        # Encode categorical columns
        categorical_encoded = []
        for col in categorical_cols:
            le = LabelEncoder()
            valid_data = data[col].dropna()
            if len(valid_data) > 0:
                le.fit(valid_data)
                self.label_encoders[col] = le
                encoded = data[col].map(lambda x: le.transform([x])[0] if pd.notna(x) else np.nan)
                categorical_encoded.append(encoded.values.reshape(-1, 1))
        
        # Combine numeric and categorical data, keeping only complete cases
        processed_data = numeric_scaled
        if categorical_encoded:
            categorical_array = np.hstack(categorical_encoded)
            mask = ~np.isnan(categorical_array).any(axis=1)
            processed_data = np.hstack([numeric_scaled[mask], categorical_array[mask]])
        
        return processed_data
    
    def train(self, 
              data: pd.DataFrame, 
              n_components: int = 3,
              epochs: int = 100,
              max_sample_size: int = 100000,
              batch_size: int = 64,
              gradient_accumulation_steps: int = 1,
              max_training_time: Optional[float] = None,
              max_epochs: Optional[int] = None,
              max_sequence_window: int = 1,
              enable_flexible_generation: bool = True,
              value_protection: bool = True,
              rare_category_replacement_method: str = "CONSTANT",
              differential_privacy: Optional[Dict] = None) -> None:
        """
        Train GAN model on complete cases.
        
        Args:
            data: Input DataFrame
            n_components: Number of components (used for latent dim)
            epochs: Number of training epochs
            max_sample_size: Maximum samples for training
            batch_size: Batch size for training
            gradient_accumulation_steps: Steps for gradient accumulation
            max_training_time: Maximum training time in seconds
            max_epochs: Maximum epochs to override epochs
            max_sequence_window: Window size for sequential data
            enable_flexible_generation: Allow dynamic sample size
            value_protection: Prevent exact value replication
            rare_category_replacement_method: Method for rare categories
            differential_privacy: Differential privacy parameters
        """
        try:
            self.data = data
            processed_data = self.preprocess_data(data)
            
            # Limit sample size
            if processed_data.shape[0] > max_sample_size:
                indices = np.random.choice(processed_data.shape[0], max_sample_size, replace=False)
                processed_data = processed_data[indices]
            
            if processed_data.shape[0] < batch_size:
                raise ValueError(f"Too few complete cases ({processed_data.shape[0]}) for batch_size ({batch_size})")
            
            # Initialize models
            input_dim = processed_data.shape[1]
            latent_dim = n_components * max_sequence_window
            self.model_generator = GeneratorNN(latent_dim, input_dim).to(self.device)
            self.model_discriminator = DiscriminatorNN(input_dim).to(self.device)
            
            # Optimizers
            g_optimizer = optim.Adam(self.model_generator.parameters(), lr=0.0002)
            d_optimizer = optim.Adam(self.model_discriminator.parameters(), lr=0.0002)
            
            # Loss function
            criterion = nn.BCELoss()
            
            # Handle rare categories
            if rare_category_replacement_method == "CONSTANT":
                for col in self.categorical_columns:
                    if col in self.label_encoders:
                        value_counts = data[col].value_counts()
                        rare_mask = value_counts < 5
                        if rare_mask.any():
                            data.loc[data[col].isin(value_counts[rare_mask].index), col] = "RARE"
            
            # Training loop
            start_time = time.time()
            max_epochs = max_epochs or epochs
            dataset = torch.tensor(processed_data, dtype=torch.float32).to(self.device)
            data_loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=True)
            
            for epoch in range(min(epochs, max_epochs)):
                g_loss_avg, d_loss_avg = 0.0, 0.0
                for i, real_data in enumerate(data_loader):
                    batch_size = real_data.size(0)
                    
                    # Train discriminator
                    d_optimizer.zero_grad()
                    real_labels = torch.ones(batch_size, 1).to(self.device)
                    fake_labels = torch.zeros(batch_size, 1).to(self.device)
                    
                    # Real data
                    d_real = self.model_discriminator(real_data)
                    d_loss_real = criterion(d_real, real_labels)
                    
                    # Fake data
                    noise = torch.randn(batch_size, latent_dim).to(self.device)
                    fake_data = self.model_generator(noise)
                    d_fake = self.model_discriminator(fake_data.detach())
                    d_loss_fake = criterion(d_fake, fake_labels)
                    
                    d_loss = (d_loss_real + d_loss_fake) / 2
                    d_loss.backward()
                    d_optimizer.step()
                    
                    # Train generator
                    g_optimizer.zero_grad()
                    fake_output = self.model_discriminator(fake_data)
                    g_loss = criterion(fake_output, real_labels)
                    g_loss.backward()
                    g_optimizer.step()
                    
                    g_loss_avg += g_loss.item()
                    d_loss_avg += d_loss.item()
                    
                    # Gradient accumulation
                    if (i + 1) % gradient_accumulation_steps == 0:
                        g_optimizer.step()
                        d_optimizer.step()
                        g_optimizer.zero_grad()
                        d_optimizer.zero_grad()
                
                # Log progress
                self.logger.info(
                    f"Epoch {epoch+1}/{min(epochs, max_epochs)}, "
                    f"G Loss: {g_loss_avg/len(data_loader):.4f}, "
                    f"D Loss: {d_loss_avg/len(data_loader):.4f}"
                )
                
                # Check time limit
                if max_training_time and (time.time() - start_time) > max_training_time:
                    self.logger.info("Max training time reached")
                    break
            
            # Save model state
            torch.save(self.model_generator.state_dict(), "generator.pth")
            torch.save(self.model_discriminator.state_dict(), "discriminator.pth")
            
        except Exception as e:
            self.logger.error(f"Error training model: {str(e)}")
            raise